
doc_events = {}

override_whitelisted_methods = {
    "shopify_webhooks.shopify_webhook_handler": "shopify_integration.shopify_webhooks.shopify_webhook_handler"
}
