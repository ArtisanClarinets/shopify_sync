
import frappe
import json

@frappe.whitelist(allow_guest=True)
def shopify_webhook_handler():
    try:
        data = frappe.request.get_data(as_text=True)
        topic = frappe.get_request_header("X-Shopify-Topic")
        shop = frappe.get_request_header("X-Shopify-Shop-Domain")

        if not (data and topic and shop):
            frappe.throw("Missing data, topic, or shop headers.")

        frappe.enqueue(
            "shopify_integration.shopify_integration.process_shopify_event",
            queue="long",
            topic=topic,
            data=json.loads(data),
            shop=shop
        )
        return "Webhook received"
    except Exception as e:
        frappe.log_error(f"Webhook error: {str(e)}", "Shopify Webhook")
        frappe.response.http_status_code = 400
        return "Error"
