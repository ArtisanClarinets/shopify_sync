
import frappe
from frappe.utils import now_datetime

def process_shopify_event(topic, data, shop):
    mapping = frappe.get_all("Shopify Webhook Mapping", filters={"webhook_topic": topic, "enabled": 1}, fields=["*"])
    if not mapping:
        log_sync_status(data.get("id"), "Unknown", "Failed", f"No mapping for topic: {topic}", topic)
        return

    m = mapping[0]
    try:
        if m.custom_script:
            exec(m.custom_script, {"data": data})
            log_sync_status(data.get("id"), m.target_doctype, "Success", "Processed with custom script", topic)
        else:
            _default_create_doc(data, m.target_doctype)
            log_sync_status(data.get("id"), m.target_doctype, "Success", "Created via default", topic)
    except Exception as e:
        log_sync_status(data.get("id"), m.target_doctype, "Failed", str(e), topic)
        frappe.log_error(f"Shopify sync failed for {topic}: {str(e)}", "Shopify Integration")

def _default_create_doc(data, doctype):
    doc = frappe.new_doc(doctype)

    if doctype == "Customer":
        doc.customer_name = f"{data.get('first_name', '')} {data.get('last_name', '')}".strip()
        doc.email = data.get("email")
        doc.shopify_customer_id = data.get("id")
    elif doctype == "Item":
        variant = data.get("variants", [])[0]
        doc.item_code = variant.get("sku") or str(variant.get("id"))
        doc.item_name = data.get("title")
        doc.description = data.get("body_html")
        doc.shopify_variant_id = variant.get("id")
        doc.stock_uom = "Nos"
        doc.is_stock_item = 1
    elif doctype == "Sales Order":
        customer_id = data.get("customer", {}).get("id")
        customer = frappe.db.get_value("Customer", {"shopify_customer_id": customer_id}, "name")
        if not customer:
            raise Exception("Customer not found for order.")
        doc.customer = customer
        doc.delivery_date = now_datetime()
        doc.shopify_order_id = data.get("id")
        for item in data.get("line_items", []):
            item_code = frappe.db.get_value("Item", {"shopify_variant_id": item["variant_id"]}, "name")
            if item_code:
                doc.append("items", {
                    "item_code": item_code,
                    "qty": item.get("quantity"),
                    "rate": float(item.get("price", 0))
                })
    else:
        raise Exception(f"No default handler for Doctype {doctype}")
    doc.insert(ignore_permissions=True)

def log_sync_status(reference_id, reference_type, status, details, topic):
    frappe.get_doc({
        "doctype": "Shopify Sync Log",
        "reference_id": reference_id,
        "reference_type": reference_type,
        "status": status,
        "details": details,
        "shopify_topic": topic,
        "timestamp": now_datetime()
    }).insert(ignore_permissions=True)
